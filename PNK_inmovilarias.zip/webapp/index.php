<?php
/**
 * PUNTO DE ENTRADA
 * Archivo: index.php
 * Redirige al dashboard según rol, o al login si no hay sesión.
 */
declare(strict_types=1);

require_once __DIR__ . '/php/includes/sesion.php';

if (!Sesion::estaAutenticado()) {
    header('Location: /html/login.html');
    exit;
}

$destinos = [
    5 => '/html/admin/dashboard.html',
    4 => '/html/propietario/dashboard.html',
    3 => '/html/gestor/dashboard.html',
    2 => '/html/usuario/dashboard.html',
    1 => '/html/usuario/dashboard.html',
];

$nivel = Sesion::nivelRol();
header('Location: ' . ($destinos[$nivel] ?? '/html/login.html'));
exit;
